"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";

interface HeaderProps {
  onBackClick?: () => void;
  onSave?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onBackClick, onSave }) => {
  const router = useRouter();

  return (
    <header className="border-b border-border bg-background shadow-sm h-20 px-6">
      <div className="flex items-center justify-between h-full w-full">
        <div className="flex items-center gap-12">
          <Image
            src="/logo.png"
            alt="Logo"
            width={148}
            height={32}
            className="object-contain mr-6"
          />
          <Button
            variant="ghost"
            onClick={onBackClick || (() => router.replace("/dashboard"))}
            className="text-muted-foreground text-sm"
          >
            ← Profile Setting
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Button
            className="bg-primary hover:bg-primary/90 text-white"
            onClick={onSave}
          >
            Save Changes
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
